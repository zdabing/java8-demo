<template>
  <div>
    <h1>高级资料</h1>
  </div>
</template>
