<template>
  <div>
    <h1>
      工资表管理
    </h1>
  </div>
</template>
